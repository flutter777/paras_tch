package com.example.paras_tech_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
